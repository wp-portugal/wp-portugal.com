<?php
/**
 * Template part for off canvas menu
 *
 * @package WordPress
 * @subpackage FoundationPress
 * @since FoundationPress 1.0
 */

?>
<aside class="left-off-canvas-menu" aria-hidden="true">
    <?php foundationpress_mobile_off_canvas(); ?>
</aside>